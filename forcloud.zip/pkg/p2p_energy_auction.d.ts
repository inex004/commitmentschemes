/* tslint:disable */
/* eslint-disable */

export class BrowserNode {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * The webpage calls this when the user taps "Submit Bid".
     * It runs your heavy cryptographic math natively on the phone's CPU!
     */
    generate_commit_payload(bid_amount: bigint): string;
    /**
     * The webpage calls this to get the phone's unique PeerID to display on screen
     */
    get_peer_id(): string;
    /**
     * The webpage calls this when the Reveal Phase starts
     */
    get_reveal_nonce_hex(): string;
    /**
     * This is called exactly once when the web page loads on the phone.
     */
    constructor();
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_browsernode_free: (a: number, b: number) => void;
    readonly browsernode_generate_commit_payload: (a: number, b: bigint) => [number, number];
    readonly browsernode_get_peer_id: (a: number) => [number, number];
    readonly browsernode_get_reveal_nonce_hex: (a: number) => [number, number];
    readonly browsernode_new: () => number;
    readonly wasm_bindgen__convert__closures_____invoke__h5ccfdf53a215f6b2: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen__convert__closures_____invoke__h4d8c56f8ec9026cb: (a: number, b: number) => void;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_destroy_closure: (a: number, b: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
