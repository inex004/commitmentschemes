/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_browsernode_free: (a: number, b: number) => void;
export const browsernode_generate_commit_payload: (a: number, b: bigint) => [number, number];
export const browsernode_get_peer_id: (a: number) => [number, number];
export const browsernode_get_reveal_nonce_hex: (a: number) => [number, number];
export const browsernode_new: () => number;
export const browsernode_verify_commitment: (a: number, b: number, c: number, d: bigint, e: number, f: number, g: number, h: number) => number;
export const wasm_bindgen__convert__closures_____invoke__h5ccfdf53a215f6b2: (a: number, b: number, c: any) => [number, number];
export const wasm_bindgen__convert__closures_____invoke__h4d8c56f8ec9026cb: (a: number, b: number) => void;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_destroy_closure: (a: number, b: number) => void;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_start: () => void;
